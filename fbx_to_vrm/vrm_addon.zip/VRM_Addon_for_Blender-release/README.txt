# VRM Add-on for Blender

See https://vrm-addon-for-blender.info for more information.
